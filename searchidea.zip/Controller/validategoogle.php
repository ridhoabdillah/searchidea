<?php
session_start();

$_SESSION['acces_token']="";
$_SESSION['acces_profile']="";

header('location:index.php');