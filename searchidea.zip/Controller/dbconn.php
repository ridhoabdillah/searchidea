<?php
	$host = 'localhost';
	$username = 'root';
	$password = '';
	$dbname = 'searchidea';
	$con = mysqli_connect($host, $username, $password, $dbname);
?>